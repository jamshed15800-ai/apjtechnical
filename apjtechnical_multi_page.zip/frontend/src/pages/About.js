import React from 'react';
export default function About(){
  return (
    <div style={{fontFamily:'sans-serif', padding:16, maxWidth:900, margin:'auto'}}>
      <h2>About Us</h2>
      <p>Founder: DR FIROZ ALAM</p>
      <p>Director: MD ABDUL KUDUSS KHAN</p>
      <p>APJ Abdul Kalam Technical Institute has been providing vocational and technical education since 2006.</p>
    </div>
  );
}

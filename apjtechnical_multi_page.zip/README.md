APJ Abdul Kalam Technical Institute - Multi-page Ready Starter

This is a ready starter project (Firebase Hosting + Functions + React) prepared for mobile deployment.

Institute: APJ Abdul Kalam Technical Institute, Patna

Tagline: Empowering Future Engineers Through Technical Excellence

Contact: H4XG+M58, Beer Chand Patel Path, Patna, Bihar 800001
Phone: 9661092285 / 7778880965
Email: info@apjtechnical.in


Admin (add this user in Firebase Auth):
Email: apjkalam1580@gmail.com
Password: apj158@#?

Courses:
  - Diploma in Mechanical Engineering
  - Diploma in Electrical Engineering
  - Diploma in Civil Engineering
  - Diploma in Computer Application & Programming
  - ITI Trades (Electrician / Fitter / Welder)
  - Diploma in HVAC
  - Diploma in Safety

Founder: DR FIROZ ALAM
Director: MD ABDUL KUDUSS KHAN

Deployment:
1) Upload this repo to GitHub
2) Connect repo to Firebase Hosting & Functions (use public dir frontend/build and functions dir functions)
3) Enable Firestore and Storage and Authentication (Email/Password) in Firebase console
4) Add admin user in Firebase Auth (email above)
5) After deploy open the site and go to /admin to create certificates
